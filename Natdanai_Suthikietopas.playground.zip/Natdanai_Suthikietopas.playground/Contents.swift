import UIKit

//Find middle index

func findMiddleIndex(data: [Int]) {
    var middleIndex: Int?
    var frontSummary = 0
    var behindSummary = 0
    var frontSummaryList: [Int] = []
    var behindSummaryList: [Int] = []
    for (frontIndex, frontValue) in data.enumerated() {
        let indexCompare = (data.count - 1) - frontIndex
        frontSummaryList.append(frontSummary + frontValue)
        frontSummary = frontSummary + frontValue
        for (behindIndex, behindValue) in data.enumerated() {
            if behindIndex == indexCompare {
                behindSummaryList.append(behindSummary + behindValue)
                behindSummary = behindSummary + behindValue
            }
        }
    }
    for (frontIndex, frontValue) in frontSummaryList.enumerated() {
        let indexCompare = (data.count - 1) - frontIndex
        for (behindIndex, behindValue) in behindSummaryList.enumerated() {
            if behindIndex == indexCompare,
               frontValue == behindValue ,
               middleIndex == nil {
                middleIndex = frontIndex
            }
        }
    }
    
    if let result = middleIndex {
        print("Input \(data),middle index is \(result)")
    } else {
        print("Input \(data),index not found")
    }
}

print("---Find middle index---")
findMiddleIndex(data: [3, 6, 8, 1, 5, 10, 1, 7])
findMiddleIndex(data: [1, 3, 5, 7, 9])
findMiddleIndex(data: [3, 5, 6])

//detect Palindrome
func validatePalindrome(_ string: String) {
    var result = true
    for (frontIndex, frontCharactor) in string.enumerated() {
        let indexCompare = (string.count - 1) - frontIndex
        for (behindIndex, behindCharactor) in string.enumerated() {
            if behindIndex == indexCompare {
                let isCompare = frontCharactor.uppercased() == behindCharactor.uppercased()
                result = result && isCompare
            }
        }
    }
    let resultWording = result ? "is a Palindrome" : "isn’t a Palindrome"
    print("input => \(string), output => “\(string) \(resultWording)")
}

print("\n---Detect Palindrome---")
validatePalindrome("Level")
validatePalindrome("Anna")
validatePalindrome("Love")

